/*
 * Booking System Backend - Spring Boot
 */
package com.example.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the Booking System.
 */
@SpringBootApplication
public class BookingApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookingApplication.class, args);
    }
}

// ------------------ Model ------------------
package com.example.booking.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Represents a service offered for booking.
 */
@Entity
public class ServiceItem {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private int duration;
    private double price;
    // Getters and setters
}

/**
 * Represents a customer booking.
 */
@Entity
public class Booking {

    @Id
    @GeneratedValue
    private Long id;
    private String customerName;
    private LocalDateTime dateTime;

    @ManyToOne
    private ServiceItem service;
    // Getters and setters
}

// ------------------ Repository ------------------
package com.example.booking.repository;

import com.example.booking.model.Booking;
import com.example.booking.model.ServiceItem;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}

public interface ServiceItemRepository extends JpaRepository<ServiceItem, Long> {
}

// ------------------ Controller ------------------
package com.example.booking.controller;

import com.example.booking.model.Booking;
import com.example.booking.model.ServiceItem;
import com.example.booking.repository.BookingRepository;
import com.example.booking.repository.ServiceItemRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for services and bookings.
 */
@RestController
@RequestMapping("/api")
public class BookingController {

    private final ServiceItemRepository serviceRepo;
    private final BookingRepository bookingRepo;

    public BookingController(ServiceItemRepository serviceRepo, BookingRepository bookingRepo) {
        this.serviceRepo = serviceRepo;
        this.bookingRepo = bookingRepo;
    }

    @GetMapping("/services")
    public List<ServiceItem> getAllServices() {
        return serviceRepo.findAll();
    }

    @PostMapping("/bookings")
    public Booking makeBooking(@RequestBody Booking booking) {
        return bookingRepo.save(booking);
    }

    @GetMapping("/bookings")
    public List<Booking> getBookings() {
        return bookingRepo.findAll();
    }
}

// ------------------ Strategy Pattern ------------------


package com.example.booking.strategy;

public interface NotificationStrategy {

    void send(String message);
}



package com.example.booking.strategy;

public class EmailNotification implements NotificationStrategy {

    public void send(String message) {
        System.out.println("Sending EMAIL: " + message);
    }
}



package com.example.booking.strategy;

public class SmsNotification implements NotificationStrategy {

    public void send(String message) {
        System.out.println("Sending SMS: " + message);
    }
}

// ------------------ application.properties ------------------
spring

.datasource.url=jdbc:sqlite:booking.db
spring.datasource.driver-class

  -name=org.sqlite.JDBC
spring.jpa.database-platform=org.hibernate.dialect.SQLiteDialect
spring.jpa.hibernate.ddl-auto=update

// ------------------ Sample Data (data.sql) ------------------
INSERT INTO service_item (id, name, duration, price) VALUES (1, 'tokyo', 30, 25.0);
INSERT INTO service_item (id, name, duration, price) VALUES (2, 'pasris', 60, 50.0);
INSERT INTO service_item (id, name, duration, price) VALUES (3, 'spain', 45, 40.0);

// ------------------ Test ------------------
package com.example.booking;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BookingTest {

    @Test
    void testTrue() {
        assertTrue(true);
    }
}
