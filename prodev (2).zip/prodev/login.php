<?php
require 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user"] = $user["name"];
        header("Location: welcome.php");
    } else {
        echo " Invalid credentials.";
    }
}

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$payload = [
    "iss" => "your-domain.com",
    "sub" => $user['id'],
    "iat" => time(),
    "exp" => time() + 3600 
];
//jwt is generated
$jwt = JWT::encode($payload, $secretKey, 'HS256');
//store in cookie
setcookie("token", $jwt, time() + 3600, "/");
//on welcome the token is verified
$decoded = JWT::decode($jwtFromHeader, new Key($secretKey, 'HS256'));
$userId = $decoded->sub;

?>

<form method="POST">
    Email: <input name="email"><br>
    Password: <input name="password" type="password"><br>
    <button type="submit">Login</button>
</form>
