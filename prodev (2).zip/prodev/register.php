<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $password]);

    echo "✅ Registration successful. <a href='login.php'>Login here</a>";
}
?>

<form method="POST">
    Name: <input name="name"><br>
    Email: <input name="email"><br>
    Password: <input name="password" type="password"><br>
    <button type="submit">Register</button>
</form>